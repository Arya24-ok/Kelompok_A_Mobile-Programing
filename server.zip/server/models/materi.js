// models/Materi.js
const mongoose = require('mongoose');

const MateriSchema = new mongoose.Schema({
  // --- TAMBAHKAN FIELD INI ---
  bab: {
    type: mongoose.Schema.Types.ObjectId, // Menyimpan ID dari dokumen Bab
    ref: 'Bab', // Merujuk ke model 'Bab'
    required: true, // Setiap materi harus masuk ke dalam satu Bab
  },
  // -------------------------
  judul: { type: String, required: true },
  deskripsi: { type: String, required: true },
  youtubeUrl: { type: String },
  driveVideoUrl: { type: String },
  driveFileUrl: { type: String },
  audioUrl: { type: String },
  tanggalDibuat: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Materi', MateriSchema);
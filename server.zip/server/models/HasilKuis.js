// models/HasilKuis.js
const mongoose = require('mongoose');

const HasilKuisSchema = new mongoose.Schema({
  kuis: { type: mongoose.Schema.Types.ObjectId, ref: 'Kuis', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  jawaban: [
    {
      pertanyaanId: { type: mongoose.Schema.Types.ObjectId, ref: 'Pertanyaan' },
      jawabanDiberikan: { type: String }
    }
  ],
  skor: { type: Number, required: true },
  totalBenar: { type: Number, required: true },
  totalSoal: { type: Number, required: true },
  tanggalSelesai: { type: Date, default: Date.now }
});

module.exports = mongoose.model('HasilKuis', HasilKuisSchema);
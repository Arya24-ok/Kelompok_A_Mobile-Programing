// models/Bab.js
const mongoose = require('mongoose');

const BabSchema = new mongoose.Schema({
  judul: {
    type: String,
    required: true,
    unique: true, // Judul Bab harus unik
  },
  urutan: { // Opsional, untuk mengurutkan bab
    type: Number,
  },
  tanggalDibuat: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Bab', BabSchema);
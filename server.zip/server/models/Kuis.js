// models/Kuis.js
const mongoose = require('mongoose');

const KuisSchema = new mongoose.Schema({
  bab: { // Kuis ini milik Bab mana
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bab',
    required: true,
  },
  judul: {
    type: String,
    required: true,
  },
  deskripsi: {
    type: String,
  },
  // [PENTING] Tambahkan ini agar batas pengerjaan bisa disimpan ke database
  maxAttempts: {
    type: Number,
    default: 0, // 0 artinya Unlimited/Tak Terbatas
  },
  // Opsi untuk admin: Tampilkan nilai ke siswa?
  nilaiTampil: {
    type: Boolean,
    default: true, // Defaultnya, nilai ditampilkan
  },
  tanggalDibuat: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Kuis', KuisSchema);
// models/Pertanyaan.js
const mongoose = require('mongoose');

const PertanyaanSchema = new mongoose.Schema({
  kuis: { // Pertanyaan ini milik Kuis mana
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Kuis',
    required: true,
  },
  teks: { // Isi pertanyaannya
    type: String,
    required: true,
  },
  tipe: { // 'pilgan' atau 'esai'
    type: String,
    required: true,
    enum: ['pilgan', 'esai'],
  },
  // --- Untuk Pilihan Ganda ---
  opsi: [{ // Array string untuk pilihan jawaban
    type: String,
  }],
  jawabanBenar: { // Index (0, 1, 2, ...) atau teks jawaban benar
    type: String, // Bisa String (untuk esai?) atau Number (index pilgan)
  },
  // --------------------------
  // Mungkin perlu field lain: bobot nilai, dll.
});

module.exports = mongoose.model('Pertanyaan', PertanyaanSchema);
// Import library yang dibutuhkan
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Import Model User, Materi, dan Bab, Kuis, Pertanyaan, Hasil Kuis
const User = require('./models/User');
const Materi = require('./models/Materi');
const Bab = require('./models/Bab');
const Kuis = require('./models/Kuis');
const Pertanyaan = require('./models/Pertanyaan');
const HasilKuis = require('./models/HasilKuis');

// Inisialisasi aplikasi express
const app = express();

// Gunakan middleware
app.use(cors());
app.use(express.json());

// Ambil Connection String dan JWT Secret dari file .env
const dbURI = process.env.MONGO_URI;
const jwtSecret = process.env.JWT_SECRET || 'ganti_dengan_kunci_rahasIA_default_yang_kuat';

// Hubungkan ke MongoDB
mongoose.connect(dbURI)
  .then(() => console.log('Koneksi ke MongoDB berhasil!'))
  .catch((err) => console.error('Koneksi ke MongoDB gagal:', err));

// --- AUTH MIDDLEWARE ---
const auth = (req, res, next) => {
  const token = req.header('x-auth-token');
  if (!token) {
    return res.status(401).json({ msg: 'Tidak ada token, otorisasi ditolak' });
  }
  try {
    const decoded = jwt.verify(token, jwtSecret);
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ msg: 'Token tidak valid' });
  }
};

// --- AUTH ROUTES ---
app.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    let user = await User.findOne({ username });
    if (user) return res.status(400).json({ msg: 'Username sudah digunakan' });
    user = new User({ username, password });
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);
    await user.save();
    res.status(201).json({ msg: 'Registrasi berhasil' });
  } catch (err) { console.error(err.message); res.status(500).send('Server error'); }
});

app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ msg: 'Username atau password salah' });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Username atau password salah' });
    const payload = { user: { id: user.id, role: user.role } };
    jwt.sign(payload, jwtSecret, { expiresIn: '1h' }, (err, token) => {
        if (err) throw err;
        res.json({ token: token, role: user.role, username: user.username });
      }
    );
  } catch (err) { console.error(err.message); res.status(500).send('Server error'); }
});

// --- BAB ROUTES ---
app.get('/bab', async (req, res) => {
  try {
    const daftarBab = await Bab.find().sort({ urutan: 1, judul: 1 });
    res.json(daftarBab);
  } catch (err) { console.error('Error mengambil Bab:', err.message); res.status(500).send('Server Error'); }
});

app.post('/bab', async (req, res) => {
  try {
    const { judul, urutan } = req.body;
    if (!judul) return res.status(400).json({ msg: 'Judul Bab tidak boleh kosong' });
    let babAda = await Bab.findOne({ judul });
    if (babAda) return res.status(400).json({ msg: 'Judul Bab sudah ada' });
    const babBaru = new Bab({ judul, urutan });
    const bab = await babBaru.save();
    res.status(201).json(bab);
  } catch (err) { console.error('Error menambah Bab:', err.message); res.status(500).send('Server Error'); }
});

// [BARU] PUT: Update Judul Bab
app.put('/bab/:babId', async (req, res) => {
  try {
    const babId = req.params.babId;
    const { judul, urutan } = req.body;

    if (!mongoose.Types.ObjectId.isValid(babId)) {
      return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    }

    const updateData = {};
    if (judul) updateData.judul = judul;
    if (urutan) updateData.urutan = urutan;

    const bab = await Bab.findByIdAndUpdate(
      babId,
      { $set: updateData },
      { new: true }
    );

    if (!bab) return res.status(404).json({ msg: 'Bab tidak ditemukan' });
    res.json(bab);
  } catch (err) {
    console.error('Error update Bab:', err.message);
    res.status(500).send('Server Error');
  }
});

// [BARU] DELETE: Hapus Bab
app.delete('/bab/:babId', async (req, res) => {
  try {
    const babId = req.params.babId;

    if (!mongoose.Types.ObjectId.isValid(babId)) {
      return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    }

    const bab = await Bab.findByIdAndDelete(babId);

    if (!bab) return res.status(404).json({ msg: 'Bab tidak ditemukan' });

    // Hapus juga Materi dan Kuis yang ada di dalam Bab ini agar database bersih
    await Materi.deleteMany({ bab: babId });
    await Kuis.deleteMany({ bab: babId });

    res.json({ msg: 'Bab berhasil dihapus beserta isinya' });
  } catch (err) {
    console.error('Error hapus Bab:', err.message);
    res.status(500).send('Server Error');
  }
});

// --- MATERI ROUTES ---
app.post('/materi', async (req, res) => {
  try {
    const { babId, judul, deskripsi, youtubeUrl, driveVideoUrl, driveFileUrl, audioUrl } = req.body;
    if (!babId || !judul || !deskripsi) return res.status(400).json({ msg: 'Bab ID, Judul, dan Deskripsi wajib diisi' });
    const bab = await Bab.findById(babId);
    if (!bab) return res.status(404).json({ msg: 'Bab tidak ditemukan' });
    const materiBaru = new Materi({ bab: babId, judul, deskripsi, youtubeUrl, driveVideoUrl, driveFileUrl, audioUrl });
    const materi = await materiBaru.save();
    res.status(201).json(materi);
  } catch (err) {
    console.error('Error saat menambah materi:', err.message);
    if (err.kind === 'ObjectId') return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    res.status(500).send('Server error');
  }
});

app.get('/bab/:babId/materi', async (req, res) => {
  try {
    const babId = req.params.babId;
    if (!mongoose.Types.ObjectId.isValid(babId)) return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    const daftarMateri = await Materi.find({ bab: babId }).sort({ tanggalDibuat: -1 });
    res.json(daftarMateri);
  } catch (err) { console.error('Error mengambil materi per Bab:', err.message); res.status(500).send('Server Error'); }
});

app.get('/materi/:materiId', async (req, res) => {
  try {
    const materiId = req.params.materiId;
    if (!mongoose.Types.ObjectId.isValid(materiId)) return res.status(400).json({ msg: 'Format Materi ID tidak valid' });
    const materi = await Materi.findById(materiId).populate('bab', 'judul');
    if (!materi) return res.status(404).json({ msg: 'Materi tidak ditemukan' });
    res.json(materi);
  } catch (err) { console.error('Error mengambil detail materi:', err.message); res.status(500).send('Server Error'); }
});

app.put('/materi/:materiId', async (req, res) => {
  try {
    const materiId = req.params.materiId;
    if (!mongoose.Types.ObjectId.isValid(materiId)) return res.status(400).json({ msg: 'Format Materi ID tidak valid' });
    const { judul, deskripsi, youtubeUrl, driveVideoUrl, driveFileUrl, audioUrl } = req.body;
    const updateData = {};
    if (judul !== undefined) updateData.judul = judul;
    if (deskripsi !== undefined) updateData.deskripsi = deskripsi;
    if (youtubeUrl !== undefined) updateData.youtubeUrl = youtubeUrl;
    if (driveVideoUrl !== undefined) updateData.driveVideoUrl = driveVideoUrl;
    if (driveFileUrl !== undefined) updateData.driveFileUrl = driveFileUrl;
    if (audioUrl !== undefined) updateData.audioUrl = audioUrl;
    const materiTerupdate = await Materi.findByIdAndUpdate(materiId, { $set: updateData }, { new: true });
    if (!materiTerupdate) return res.status(404).json({ msg: 'Materi tidak ditemukan untuk diupdate' });
    res.json(materiTerupdate);
  } catch (err) { console.error('Error mengupdate materi:', err.message); res.status(500).send('Server Error'); }
});

app.delete('/materi/:materiId', async (req, res) => {
  try {
    const materiId = req.params.materiId;
    if (!mongoose.Types.ObjectId.isValid(materiId)) return res.status(400).json({ msg: 'Format Materi ID tidak valid' });
    const materi = await Materi.findByIdAndDelete(materiId);
    if (!materi) return res.status(404).json({ msg: 'Materi tidak ditemukan untuk dihapus' });
    res.json({ msg: 'Materi berhasil dihapus' });
  } catch (err) { console.error('Error menghapus materi:', err.message); res.status(500).send('Server Error'); }
});

// --- RUTE KUIS ---

// GET: Mendapatkan semua Kuis dalam satu Bab
app.get('/bab/:babId/kuis', async (req, res) => {
  try {
    const babId = req.params.babId;
    if (!mongoose.Types.ObjectId.isValid(babId)) {
      return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    }
    const daftarKuis = await Kuis.find({ bab: babId }).sort({ tanggalDibuat: 1 });
    res.json(daftarKuis);
  } catch (err) {
    console.error('Error mengambil kuis per Bab:', err.message);
    res.status(500).send('Server Error');
  }
});

// POST: Menambah Kuis baru
app.post('/bab/:babId/kuis', async (req, res) => {
  try {
    const babId = req.params.babId;
    const { judul, deskripsi, maxAttempts, nilaiTampil } = req.body;

    if (!mongoose.Types.ObjectId.isValid(babId)) {
      return res.status(400).json({ msg: 'Format Bab ID tidak valid' });
    }
    const bab = await Bab.findById(babId);
    if (!bab) {
      return res.status(404).json({ msg: 'Bab tidak ditemukan' });
    }
    if (!judul) {
      return res.status(400).json({ msg: 'Judul kuis wajib diisi' });
    }

    const kuisBaru = new Kuis({
      bab: babId,
      judul,
      deskripsi,
      maxAttempts: maxAttempts ?? 1,
      nilaiTampil: nilaiTampil ?? true,
    });

    const kuis = await kuisBaru.save();
    res.status(201).json(kuis);
  } catch (err) {
    console.error('Error menambah Kuis:', err.message);
    res.status(500).send('Server Error');
  }
});

// PUT: Memperbarui Kuis
app.put('/kuis/:kuisId', async (req, res) => {
  try {
    const { kuisId } = req.params;
    const { judul, deskripsi, maxAttempts, nilaiTampil } = req.body;

    if (!mongoose.Types.ObjectId.isValid(kuisId)) {
      return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
    }

    const updateData = {};
    if (judul !== undefined) updateData.judul = judul;
    if (deskripsi !== undefined) updateData.deskripsi = deskripsi;
    if (maxAttempts !== undefined) updateData.maxAttempts = maxAttempts;
    if (nilaiTampil !== undefined) updateData.nilaiTampil = nilaiTampil;

    const kuis = await Kuis.findByIdAndUpdate(
      kuisId,
      { $set: updateData },
      { new: true }
    );

    if (!kuis) return res.status(404).json({ msg: 'Kuis tidak ditemukan' });
    res.json(kuis);
  } catch (err) {
    console.error('Error mengupdate Kuis:', err.message);
    res.status(500).send('Server Error');
  }
});

// DELETE: Menghapus Kuis
app.delete('/kuis/:kuisId', async (req, res) => {
    try {
        const { kuisId } = req.params;
        
        if (!mongoose.Types.ObjectId.isValid(kuisId)) {
            return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
        }

        const kuis = await Kuis.findByIdAndDelete(kuisId);

        if (!kuis) {
            return res.status(404).json({ msg: 'Kuis tidak ditemukan' });
        }

        await Pertanyaan.deleteMany({ kuis: kuisId });

        res.json({ msg: 'Kuis berhasil dihapus' });
    } catch (err) {
        console.error('Error menghapus Kuis:', err.message);
        res.status(500).send('Server Error');
    }
});

// --- RUTE PERTANYAAN ---

// GET: Mendapatkan semua Pertanyaan (DENGAN PROTEKSI AUTH & LIMIT)
// [PERUBAHAN PENTING]: Ditambahkan 'auth' middleware dan logika cek batas pengerjaan
app.get('/kuis/:kuisId/pertanyaan', auth, async (req, res) => {
  try {
    const { kuisId } = req.params;
    const userId = req.user.id; // Didapat dari auth middleware

    if (!mongoose.Types.ObjectId.isValid(kuisId)) {
      return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
    }

    // 1. Cek Kuis & Batas Pengerjaan
    const kuis = await Kuis.findById(kuisId);
    if (!kuis) {
        return res.status(404).json({ msg: 'Kuis tidak ditemukan' });
    }

    // Jika kuis memiliki batas (maxAttempts > 0)
    if (kuis.maxAttempts && kuis.maxAttempts > 0) {
        // Hitung berapa kali user ini sudah mengerjakan
        const jumlahMengerjakan = await HasilKuis.countDocuments({ 
            kuis: kuisId, 
            user: userId 
        });

        // Jika sudah mencapai atau melebihi batas, tolak akses (403)
        if (jumlahMengerjakan >= kuis.maxAttempts) {
            return res.status(403).json({ 
                msg: `Kesempatan mengerjakan kuis ini sudah habis (Maksimal ${kuis.maxAttempts} kali).` 
            });
        }
    }

    // 2. Jika aman, ambil pertanyaan
    const daftarPertanyaan = await Pertanyaan.find({ kuis: kuisId }).select('-jawabanBenar');
    res.json(daftarPertanyaan);

  } catch (err) {
    console.error('Error mengambil Pertanyaan:', err.message);
    res.status(500).send('Server Error');
  }
});

// POST: Menambah Pertanyaan
app.post('/kuis/:kuisId/pertanyaan', async (req, res) => {
  try {
    const { kuisId } = req.params;
    const { teks, tipe, opsi, jawabanBenar } = req.body;

    if (!mongoose.Types.ObjectId.isValid(kuisId)) {
      return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
    }
    if (!teks || !tipe || !jawabanBenar) {
      return res.status(400).json({ msg: 'Teks, Tipe, dan Jawaban Benar wajib diisi' });
    }
    if (tipe === 'pilgan' && (!opsi || opsi.length < 2)) {
        return res.status(400).json({ msg: 'Pilihan ganda harus memiliki minimal 2 opsi' });
    }
    const kuis = await Kuis.findById(kuisId);
    if (!kuis) return res.status(404).json({ msg: 'Kuis tidak ditemukan' });
    const pertanyaanBaru = new Pertanyaan({
      kuis: kuisId,
      teks,
      tipe,
      opsi: tipe === 'pilgan' ? opsi : [],
      jawabanBenar,
    });
    const pertanyaan = await pertanyaanBaru.save();
    res.status(201).json(pertanyaan);
  } catch (err) {
    console.error('Error menambah Pertanyaan:', err.message);
    res.status(500).send('Server Error');
  }
});

// [TAMBAHAN BARU] PUT: Update Pertanyaan Spesifik
app.put('/pertanyaan/:pertanyaanId', auth, async (req, res) => {
  try {
    const { pertanyaanId } = req.params;
    const { teks, tipe, opsi, jawabanBenar } = req.body;

    if (!mongoose.Types.ObjectId.isValid(pertanyaanId)) {
      return res.status(400).json({ msg: 'ID Pertanyaan tidak valid' });
    }

    const updateData = { teks, tipe, jawabanBenar };
    if (tipe === 'pilgan') {
        updateData.opsi = opsi;
    } else {
        updateData.opsi = []; // Kosongkan opsi jika berubah jadi esai
    }

    const pertanyaan = await Pertanyaan.findByIdAndUpdate(
      pertanyaanId,
      { $set: updateData },
      { new: true }
    );

    if (!pertanyaan) return res.status(404).json({ msg: 'Pertanyaan tidak ditemukan' });
    res.json(pertanyaan);

  } catch (err) {
    console.error('Error update pertanyaan:', err.message);
    res.status(500).send('Server Error');
  }
});

// [TAMBAHAN BARU] DELETE: Hapus Pertanyaan Spesifik
app.delete('/pertanyaan/:pertanyaanId', auth, async (req, res) => {
  try {
    const { pertanyaanId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(pertanyaanId)) {
      return res.status(400).json({ msg: 'ID Pertanyaan tidak valid' });
    }

    const pertanyaan = await Pertanyaan.findByIdAndDelete(pertanyaanId);

    if (!pertanyaan) return res.status(404).json({ msg: 'Pertanyaan tidak ditemukan' });
    res.json({ msg: 'Pertanyaan berhasil dihapus' });

  } catch (err) {
    console.error('Error hapus pertanyaan:', err.message);
    res.status(500).send('Server Error');
  }
});

// --- RUTE SUBMIT & HASIL ---

// POST: Submit Jawaban Kuis
app.post('/kuis/:kuisId/submit', auth, async (req, res) => {
  try {
    const { kuisId } = req.params;
    const { jawaban: jawabanPengguna } = req.body;
    const userId = req.user.id;

    if (!mongoose.Types.ObjectId.isValid(kuisId)) {
      return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
    }
    
    // 1. Ambil Data Kuis
    const kuis = await Kuis.findById(kuisId);
    if (!kuis) {
        return res.status(404).json({ msg: 'Kuis tidak ditemukan.' });
    }

    // 2. CEK BATAS PENGERJAAN (Double Check saat submit)
    if (kuis.maxAttempts && kuis.maxAttempts > 0) {
        const jumlahPercobaan = await HasilKuis.countDocuments({ kuis: kuisId, user: userId });
        if (jumlahPercobaan >= kuis.maxAttempts) {
            return res.status(403).json({ 
                msg: `Anda telah mencapai batas maksimal pengerjaan (${kuis.maxAttempts} kali).` 
            });
        }
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(401).json({ msg: 'User ID tidak valid, silahkan login ulang' });
    }
    if (!jawabanPengguna || !Array.isArray(jawabanPengguna)) {
      return res.status(400).json({ msg: 'Format jawaban tidak valid' });
    }

    // 3. Hitung Nilai
    const semuaPertanyaan = await Pertanyaan.find({ kuis: kuisId }).select('jawabanBenar');
    const totalSoal = semuaPertanyaan.length;

    if (totalSoal === 0) {
      return res.status(404).json({ msg: 'Kuis ini belum memiliki soal' });
    }

    const jawabanBenarMap = new Map();
    semuaPertanyaan.forEach(p => {
      jawabanBenarMap.set(p._id.toString(), p.jawabanBenar);
    });

    let skorBenar = 0;
    jawabanPengguna.forEach(jawaban => {
      const jawabanBenar = jawabanBenarMap.get(jawaban.pertanyaanId);
      if (jawabanBenar && jawaban.jawaban.toLowerCase() === jawabanBenar.toLowerCase()) {
        skorBenar++;
      }
    });

    const nilaiAkhir = (skorBenar / totalSoal) * 100;

    // 4. Simpan Hasil
    const jawabanFormatted = jawabanPengguna.map(j => ({
        pertanyaanId: j.pertanyaanId,
        jawabanDiberikan: j.jawaban 
    }));

    const hasilKuisBaru = new HasilKuis({
        kuis: kuisId,
        user: userId,
        jawaban: jawabanFormatted,
        skor: Math.round(nilaiAkhir),
        totalBenar: skorBenar,
        totalSoal: totalSoal
    });

    await hasilKuisBaru.save();

    // 5. Respon
    if (kuis.nilaiTampil === false) {
        return res.json({
            msg: 'Jawaban berhasil disubmit dan disimpan. Nilai disembunyikan.',
            isNilaiDisembunyikan: true 
        });
    }

    res.json({
      msg: 'Kuis berhasil disubmit dan disimpan!',
      isNilaiDisembunyikan: false,
      skor: Math.round(nilaiAkhir), 
      totalBenar: skorBenar,
      totalSoal: totalSoal,
      totalSalah: totalSoal - skorBenar
    });

  } catch (err) {
    console.error('Error saat submit kuis:', err.message);
    res.status(500).send('Server Error');
  }
});


// GET: Mendapatkan SEMUA hasil kuis untuk 1 kuis (untuk admin/guru)
app.get('/kuis/:kuisId/hasil', auth, async (req, res) => {
    try {
        const { kuisId } = req.params;
        if (!mongoose.Types.ObjectId.isValid(kuisId)) {
            return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
        }

        const daftarHasil = await HasilKuis.find({ kuis: kuisId })
            .populate('user', 'username')
            .sort({ tanggalSelesai: -1 });

        res.json(daftarHasil);

    } catch (err) {
        console.error('Error mengambil semua hasil kuis:', err.message);
        res.status(500).send('Server Error');
    }
});

// GET: Mendapatkan riwayat hasil kuis milik SAYA (user yang login)
app.get('/kuis/:kuisId/hasil/saya', auth, async (req, res) => {
    try {
        const { kuisId } = req.params;
        const userId = req.user.id;

        if (!mongoose.Types.ObjectId.isValid(kuisId)) {
            return res.status(400).json({ msg: 'Format Kuis ID tidak valid' });
        }

        const hasilSaya = await HasilKuis.find({ kuis: kuisId, user: userId })
            .sort({ tanggalSelesai: -1 }); 

        if (!hasilSaya || hasilSaya.length === 0) {
            return res.status(404).json([]); 
        }

        res.json(hasilSaya);

    } catch (err) {
        console.error('Error mengambil hasil kuis saya:', err.message);
        res.status(500).send('Server Error');
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server berjalan di port ${PORT} dan bisa diakses dari jaringan lokal`);
});